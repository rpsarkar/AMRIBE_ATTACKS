# MCBE

This is an implementation of the paper "Compacting Ciphertext in Multi-Channel Broadcast Encryption and Attribute-Based Encryption." by Ha Minh LE, Duc Vinh TRAN, Anh Van TRINH, Viet Cuong TRINH. Theoretical Computer Science, 2020.




To compile- 	gcc bkem.c testscheme.c -lm -lgmp -lpbc


To run-        ./a.out
